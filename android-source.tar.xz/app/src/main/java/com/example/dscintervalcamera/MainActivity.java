package com.example.dscintervalcamera;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION_REQUEST = 701;
    private static final String FOLDER = "DSCIntervalCamera";
    private static final int TEXT_COLOR = Color.rgb(238, 242, 247);
    private static final int BACKGROUND = Color.rgb(16, 20, 27);
    private static final int PANEL = Color.rgb(35, 42, 52);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ConcurrentLinkedQueue<Integer> pendingNumbers = new ConcurrentLinkedQueue<>();
    private TextureView preview;
    private EditText delayField;
    private EditText intervalField;
    private EditText countField;
    private TextView status;
    private Button startButton;
    private Button stopButton;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader imageReader;
    private String cameraId;
    private Size photoSize;
    private int sensorOrientation;

    private boolean running = false;
    private boolean cameraReady = false;
    private int requestedPhotos;
    private int issuedPhotos;
    private int savedPhotos;
    private int failedPhotos;
    private long intervalMillis;
    private long nextShotAt;
    private Runnable shotRunnable;
    private Runnable countdownRunnable;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(int x) {
        return (int) (x * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildUi() {
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(12), dp(12), dp(12), dp(10));
        main.setBackgroundColor(BACKGROUND);
        setContentView(main);

        TextView heading = new TextView(this);
        heading.setText("DSC Interval Camera");
        heading.setTextSize(22);
        heading.setTextColor(TEXT_COLOR);
        heading.setGravity(Gravity.CENTER);
        main.addView(heading, new LinearLayout.LayoutParams(-1, dp(44)));

        preview = new TextureView(this);
        preview.setSurfaceTextureListener(surfaceListener);
        preview.setKeepScreenOn(true);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        previewParams.topMargin = dp(6);
        previewParams.bottomMargin = dp(10);
        main.addView(preview, previewParams);

        ScrollView optionsScroll = new ScrollView(this);
        optionsScroll.setFillViewport(false);
        main.addView(optionsScroll, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout options = new LinearLayout(this);
        options.setOrientation(LinearLayout.VERTICAL);
        optionsScroll.addView(options);

        delayField = makeField(options, "Initial delay before first photo (seconds)", "12");
        intervalField = makeField(options, "Seconds between photos", "8");
        countField = makeField(options, "Number of photos", "60");

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        options.addView(buttons, new LinearLayout.LayoutParams(-1, dp(56)));

        startButton = new Button(this);
        startButton.setText("START");
        startButton.setEnabled(false);
        buttons.addView(startButton, new LinearLayout.LayoutParams(0, -1, 1));

        stopButton = new Button(this);
        stopButton.setText("STOP");
        stopButton.setEnabled(false);
        buttons.addView(stopButton, new LinearLayout.LayoutParams(0, -1, 1));

        status = new TextView(this);
        status.setTextColor(TEXT_COLOR);
        status.setTextSize(14);
        status.setPadding(dp(3), dp(7), dp(3), dp(7));
        status.setText("Starting camera…");
        options.addView(status, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Photos save to Gallery → Pictures/" + FOLDER + "\nKeep this app in the foreground while recording.");
        note.setTextColor(Color.rgb(168, 182, 196));
        note.setTextSize(12);
        options.addView(note);
    }

    private EditText makeField(LinearLayout parent, String caption, String startingValue) {
        TextView label = new TextView(this);
        label.setText(caption);
        label.setTextSize(13);
        label.setTextColor(TEXT_COLOR);
        parent.addView(label);

        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setText(startingValue);
        field.setSelectAllOnFocus(true);
        field.setTextColor(TEXT_COLOR);
        field.setInputType(InputType.TYPE_CLASS_NUMBER);
        field.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(115, 165, 245)));
        LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(-1, dp(48));
        fieldParams.bottomMargin = dp(5);
        parent.addView(field, fieldParams);
        return field;
    }

    @Override
    protected void onResume() {
        super.onResume();
        startCameraThread();
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            if (preview.isAvailable()) openCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        }
        startButton.setOnClickListener(v -> startSequence());
        stopButton.setOnClickListener(v -> stopSequence("Stopped by user."));
    }

    @Override
    protected void onPause() {
        stopSequence("Paused. Return to the app to resume a new batch.");
        closeCamera();
        stopCameraThread();
        super.onPause();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                if (preview.isAvailable()) openCamera();
            } else {
                status.setText("Camera permission denied. Allow it in phone Settings to take photos.");
            }
        }
    }

    private final TextureView.SurfaceTextureListener surfaceListener = new TextureView.SurfaceTextureListener() {
        @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }
        @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) { }
        @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
        @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) { }
    };

    private void startCameraThread() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("DSCCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
    }

    private void stopCameraThread() {
        if (cameraThread == null) return;
        cameraThread.quitSafely();
        try { cameraThread.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        cameraThread = null;
        cameraHandler = null;
    }

    private Size choosePhotoSize(Size[] sizes) {
        // Prefer around 8MP: clear code text without enormous files.
        Size best = sizes[0];
        double bestScore = Double.POSITIVE_INFINITY;
        for (Size size : sizes) {
            long pixels = (long) size.getWidth() * size.getHeight();
            if (pixels > 13000000) continue;
            double score = Math.abs(Math.log(pixels / 8000000.0));
            if (score < bestScore) { best = size; bestScore = score; }
        }
        return best;
    }

    private Size choosePreviewSize(Size[] sizes) {
        Size best = sizes[0];
        double bestScore = Double.POSITIVE_INFINITY;
        for (Size size : sizes) {
            long pixels = (long) size.getWidth() * size.getHeight();
            if (pixels > 2200000) continue;
            double score = Math.abs(Math.log(pixels / 2000000.0));
            if (score < bestScore) { best = size; bestScore = score; }
        }
        return best;
    }

    private void openCamera() {
        if (camera != null || cameraHandler == null || !preview.isAvailable()) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String[] ids = manager.getCameraIdList();
            if (ids.length == 0) { status.setText("No camera found."); return; }
            cameraId = ids[0];
            for (String id : ids) {
                Integer facing = manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id;
                    break;
                }
            }
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            Integer angle = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrientation = angle != null ? angle : 90;
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null || map.getOutputSizes(ImageFormat.JPEG) == null) {
                status.setText("This camera does not support JPEG capture."); return;
            }
            photoSize = choosePhotoSize(map.getOutputSizes(ImageFormat.JPEG));
            Size[] previewSizes = map.getOutputSizes(SurfaceTexture.class);
            Size previewSize = previewSizes != null && previewSizes.length > 0
                    ? choosePreviewSize(previewSizes) : photoSize;
            SurfaceTexture surface = preview.getSurfaceTexture();
            if (surface == null) return;
            surface.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            if (imageReader != null) { imageReader.close(); imageReader = null; }
            imageReader = ImageReader.newInstance(photoSize.getWidth(), photoSize.getHeight(), ImageFormat.JPEG, 3);
            imageReader.setOnImageAvailableListener(reader -> {
                Image image = null;
                try {
                    image = reader.acquireNextImage();
                    if (image == null) return;
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    byte[] data = new byte[buffer.remaining()];
                    buffer.get(data);
                    Integer number = pendingNumbers.poll();
                    if (number == null) number = -1;
                    int actualNumber = number;
                    savePhoto(data, actualNumber);
                } catch (Exception e) {
                    mainHandler.post(() -> {
                        failedPhotos++;
                        updateStatus("Error reading camera image: " + e.getMessage());
                    });
                } finally {
                    if (image != null) image.close();
                }
            }, cameraHandler);
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice opened) {
                    camera = opened;
                    configurePreview();
                }
                @Override public void onDisconnected(CameraDevice disconnected) {
                    disconnected.close(); camera = null;
                    mainHandler.post(() -> stopSequence("Camera disconnected."));
                }
                @Override public void onError(CameraDevice broken, int error) {
                    broken.close(); camera = null;
                    mainHandler.post(() -> stopSequence("Camera error: " + error));
                }
            }, cameraHandler);
        } catch (Exception e) {
            status.setText("Camera setup failed: " + e.getMessage());
        }
    }

    private void configurePreview() {
        if (camera == null || imageReader == null || !preview.isAvailable()) return;
        SurfaceTexture texture = preview.getSurfaceTexture();
        if (texture == null) return;
        Surface previewSurface = new Surface(texture);
        try {
            CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(previewSurface);
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            camera.createCaptureSession(Arrays.asList(previewSurface, imageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession configured) {
                            session = configured;
                            try {
                                session.setRepeatingRequest(builder.build(), null, cameraHandler);
                                mainHandler.post(() -> {
                                    cameraReady = true;
                                    startButton.setEnabled(true);
                                    status.setText("Camera ready. Set timings and tap START.");
                                });
                            } catch (CameraAccessException e) {
                                mainHandler.post(() -> status.setText("Preview failed: " + e.getMessage()));
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession failed) {
                            mainHandler.post(() -> status.setText("Camera preview configuration failed."));
                        }
                    }, cameraHandler);
        } catch (CameraAccessException e) {
            status.setText("Camera error: " + e.getMessage());
        }
    }

    private void startSequence() {
        if (!cameraReady || session == null || camera == null) {
            status.setText("Camera is not ready yet."); return;
        }
        int delay;
        int interval;
        int count;
        try {
            delay = Integer.parseInt(delayField.getText().toString().trim());
            interval = Integer.parseInt(intervalField.getText().toString().trim());
            count = Integer.parseInt(countField.getText().toString().trim());
        } catch (NumberFormatException e) {
            status.setText("Enter whole numbers in all three settings."); return;
        }
        if (delay < 0 || delay > 3600 || interval < 2 || interval > 600 || count < 1 || count > 2000) {
            status.setText("Allowed: delay 0–3600 sec, interval 2–600 sec, photos 1–2000."); return;
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(countField.getWindowToken(), 0);
        countField.clearFocus();
        running = true;
        requestedPhotos = count;
        issuedPhotos = 0;
        savedPhotos = 0;
        failedPhotos = 0;
        pendingNumbers.clear();
        intervalMillis = interval * 1000L;
        nextShotAt = SystemClock.elapsedRealtime() + delay * 1000L;
        startButton.setEnabled(false);
        stopButton.setEnabled(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        shotRunnable = this::takeShot;
        countdownRunnable = new Runnable() {
            @Override public void run() {
                if (!running) return;
                long remaining = Math.max(0, nextShotAt - SystemClock.elapsedRealtime());
                updateStatus("Next photo in " + String.format(Locale.US, "%.1f", remaining / 1000.0) + " s");
                mainHandler.postDelayed(this, 200);
            }
        };
        mainHandler.postDelayed(shotRunnable, Math.max(0, nextShotAt - SystemClock.elapsedRealtime()));
        mainHandler.post(countdownRunnable);
    }

    private int jpegOrientation() {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees = rotation == Surface.ROTATION_90 ? 90 :
                rotation == Surface.ROTATION_180 ? 180 :
                rotation == Surface.ROTATION_270 ? 270 : 0;
        return (sensorOrientation + degrees) % 360;
    }

    private void takeShot() {
        if (!running || session == null || camera == null || imageReader == null) return;
        int number = ++issuedPhotos;
        pendingNumbers.add(number);
        try {
            CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            builder.addTarget(imageReader.getSurface());
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            builder.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation());
            session.capture(builder.build(), null, cameraHandler);
        } catch (Exception e) {
            pendingNumbers.remove(number);
            failedPhotos++;
            updateStatus("Shot " + number + " failed: " + e.getMessage());
        }
        if (issuedPhotos < requestedPhotos) {
            nextShotAt += intervalMillis;
            mainHandler.postDelayed(shotRunnable, Math.max(0, nextShotAt - SystemClock.elapsedRealtime()));
        } else {
            running = false;
            mainHandler.removeCallbacks(countdownRunnable);
            updateStatus("All photos requested. Saving remaining files…");
            maybeFinishBatch();
        }
    }

    private void savePhoto(byte[] jpeg, int number) {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        String filename = String.format(Locale.US, "DSC_%04d_%s.jpg", number, stamp);
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER);
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = null;
        boolean success = false;
        try {
            uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("MediaStore insert returned null");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("Cannot open image output stream");
                output.write(jpeg);
            }
            ContentValues completed = new ContentValues();
            completed.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, completed, null, null);
            success = true;
        } catch (Exception e) {
            if (uri != null) getContentResolver().delete(uri, null, null);
            String message = e.getMessage();
            mainHandler.post(() -> updateStatus("Save failed: " + message));
        }
        boolean saved = success;
        mainHandler.post(() -> {
            if (saved) savedPhotos++; else failedPhotos++;
            updateStatus(null);
            maybeFinishBatch();
        });
    }

    private void updateStatus(String prefix) {
        String progress = "Captured " + issuedPhotos + "/" + requestedPhotos +
                " | Saved " + savedPhotos + " | Failed " + failedPhotos;
        status.setText((prefix == null ? "" : prefix + "\n") + progress);
    }

    private void maybeFinishBatch() {
        if (!running && issuedPhotos > 0 && savedPhotos + failedPhotos >= issuedPhotos) {
            status.setText("Batch finished. Saved " + savedPhotos + "/" + requestedPhotos +
                    " photos. Check Gallery → Pictures/" + FOLDER);
            startButton.setEnabled(cameraReady);
            stopButton.setEnabled(false);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void stopSequence(String message) {
        if (shotRunnable != null) mainHandler.removeCallbacks(shotRunnable);
        if (countdownRunnable != null) mainHandler.removeCallbacks(countdownRunnable);
        boolean wasRunning = running;
        running = false;
        if (stopButton != null) stopButton.setEnabled(false);
        if (startButton != null) startButton.setEnabled(cameraReady);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (wasRunning && status != null) {
            status.setText(message + " Saved so far: " + savedPhotos + ".");
        }
    }

    private void closeCamera() {
        cameraReady = false;
        if (startButton != null) startButton.setEnabled(false);
        if (session != null) { session.close(); session = null; }
        if (camera != null) { camera.close(); camera = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
    }
}
